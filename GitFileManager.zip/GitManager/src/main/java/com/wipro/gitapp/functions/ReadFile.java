package com.wipro.gitapp.functions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * ReadFile , reads the content from the file.
 * @author bipin
 *
 */
public class ReadFile {
	
	public StringBuffer readFile(String fileName) throws IOException {
        File file = new File(fileName);
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        StringBuffer finalString = new StringBuffer();
        String line;
        while((line = br.readLine()) != null){
            //process the line
            //System.out.println(line);
            finalString = finalString.append(line);
        }
        System.out.println(finalString);
        //close resources
        br.close();
        fr.close();
		return finalString;
    }
	
	public File[] listFile(String folder) {
		File dir = new File(folder);
		if (dir.isDirectory() == false) {
			System.out.println("Directory does not exists : " + folder);
		}
		// list out all the files
		File[] files = dir.listFiles();
		if (files.length == 0) {
			System.out.println("The directory is empty:");
		} 
		return files;
	}

	
}
