package com.wipro.gitapp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WebPageNavigationController{
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String uploadByUi(Model model, HttpServletRequest req) {
		model.addAttribute("msg","Login After Sometime.");
		return "index";	
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String aurthorLoginGet(Model model, HttpServletRequest req) {
		model.addAttribute("msg","Login After Sometime.");
		return "home";	
	}
	
	@RequestMapping(value = "/fileupload", method = RequestMethod.GET)
	public String aurthorLoginGetangular(Model model, HttpServletRequest req) {
		model.addAttribute("msg","Login After Sometime.");
		return "ang";	
	}

}
