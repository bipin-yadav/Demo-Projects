package com.wipro.gitapp.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.simple.JSONObject;

import com.wipro.gitapp.functions.UploadToGit;

public class HttpClientPutForUi {
	
	private static final String DEFAULT_USER = "bipin-yadav";
	private static final String DEFAULT_PASS = "gh6293@Wipro";

	public String mainController(String url, StringBuffer result2) {
		
        DefaultHttpClient httpClient = new DefaultHttpClient();
         
        StringBuilder result = new StringBuilder();
        try {
            HttpPut putRequest = new HttpPut(url);
            putRequest.addHeader("Content-Type", "application/json");
            putRequest.addHeader("Accept", "application/json");
            //Authentication to github
            putRequest.addHeader(BasicScheme.authenticate(
            		 new UsernamePasswordCredentials(DEFAULT_USER, DEFAULT_PASS),
            		 "UTF-8", false));
            JSONObject requestBody = new JSONObject();
            requestBody.put("path", "git.py");
            requestBody.put("message", "my commit message");            
            requestBody.put("content", result2);
            StringEntity input;
            try {
                input = new StringEntity(requestBody.toString());
                System.out.println("input====="+input);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return "fail";
            }
            System.out.println("input====="+input);
            putRequest.setEntity(input);
            HttpResponse response = httpClient.execute(putRequest);
            if (response.getStatusLine().getStatusCode() != 201 ) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatusLine().getStatusCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (response.getEntity().getContent())));
            String output;
            while ((output = br.readLine()) != null) {
                result.append(output);
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result.toString();
    }
}
