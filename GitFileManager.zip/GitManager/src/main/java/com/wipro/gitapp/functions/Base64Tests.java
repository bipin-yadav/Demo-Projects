package com.wipro.gitapp.functions;

import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.util.*;

public class Base64Tests {
	private static final int TOTAL_BUFFER_SIZE = 20 * 1000 * 1000;
	private static final Base64Codec[] m_codecs = { new JavaXmlImpl() };

	/*public static void main(String[] args) throws IOException, InterruptedException {
		Map<Integer, Map<String, TestResult>> results = new HashMap<Integer, Map<String, TestResult>>(2);
		results.put(TOTAL_BUFFER_SIZE, testString(TOTAL_BUFFER_SIZE));
		System.out.println(formatResults(results));
	}*/

	private static Map<String, TestResult> testString(final int bufferSize) throws IOException, InterruptedException {
		System.out.println("inside test string");
		final Random r = new Random(125); // seed is set to make results
		final List<byte[]> buffers = new ArrayList<byte[]>(TOTAL_BUFFER_SIZE / bufferSize);
		for (int i = 0; i < TOTAL_BUFFER_SIZE / bufferSize; ++i) {
			final byte[] buf = new byte[bufferSize];
			r.nextBytes(buf);
			buffers.add(buf);
		}

		// actual run
		final Map<String, TestResult> results = new HashMap<String, TestResult>(5);
		for (final Base64Codec codec : m_codecs) {
			final String name = codec.getClass().getName();
			results.put(name.substring(name.indexOf('$') + 1), testStringCodec(codec, buffers));
			System.gc();
		}
		return results;
	}

	private static String formatResults(final Map<Integer, Map<String, TestResult>> results) {
		// sorted keys for pretty printing
		final List<Integer> sortedKeys = new ArrayList<Integer>(results.keySet());
		Collections.sort(sortedKeys);
		final List<String> sortedTests = new ArrayList<String>(results.get(sortedKeys.get(0)).keySet());
		Collections.sort(sortedTests);

		// header
		final StringBuilder sb = new StringBuilder(2048);
		sb.append("<table border=\"1\"><tr><td>Name</td>");
		for (final Integer size : sortedKeys)
			sb.append("<td>Encode, " + size + " bytes</td><td>Decode, " + size + " bytes</td>");
		sb.append("</tr>\n");
		// body
		for (final String test : sortedTests) {
			sb.append("<tr><td>" + test + "</td>");
			for (final Integer size : sortedKeys) {
				final TestResult sizeResults = results.get(size).get(test);
				sb.append("<td>" + sizeResults.encodeTime + " sec</td><td>" + sizeResults.decodeTime + " sec</td>");
			}
			sb.append("</tr>\n");
		}
		sb.append("</table>");
		return sb.toString();
	}

	private static class TestResult {
		public final double encodeTime;
		public final double decodeTime;

		private TestResult(double encodeTime, double decodeTime) {
			this.encodeTime = encodeTime;
			this.decodeTime = decodeTime;
		}
	}

	private static TestResult testStringCodec(final Base64Codec codec, final List<byte[]> buffers) throws IOException {
		final List<String> encoded = new ArrayList<String>(buffers.size());
		final long start = System.currentTimeMillis();
		for (final byte[] buf : buffers)
			encoded.add(codec.encode(buf));
		final long encodeTime = System.currentTimeMillis() - start;

		final List<byte[]> result = new ArrayList<byte[]>(buffers.size());
		final long start2 = System.currentTimeMillis();
		for (final String s : encoded)
			result.add(codec.decode(s));
		final long decodeTime = System.currentTimeMillis() - start2;

		for (int i = 0; i < buffers.size(); ++i) {
			if (!Arrays.equals(buffers.get(i), result.get(i)))
				System.out.println("Diff at pos = " + i);
		}
		return new TestResult(encodeTime / 1000.0, decodeTime / 1000.0);
	}

	private static interface Base64Codec {
		public String encode(final byte[] data);

		public byte[] decode(final String base64) throws IOException;
	}

	private static class JavaXmlImpl implements Base64Codec  
	{
		public String encode(byte[] data) {
			//System.out.println(DatatypeConverter.printBase64Binary(data));
			return DatatypeConverter.printBase64Binary(data);
		}

		public byte[] decode(String base64) throws IOException {
			//System.out.println(DatatypeConverter.parseBase64Binary(base64));
			return DatatypeConverter.parseBase64Binary(base64);
		}
	}

}
