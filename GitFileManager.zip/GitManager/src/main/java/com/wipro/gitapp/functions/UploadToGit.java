package com.wipro.gitapp.functions;

import java.io.File;
import java.io.IOException;

/**
 * UploadToGit class to get the content of the file a
 * encode the content to base64.
 * @author bipin 
 * 
 *
 */
public class UploadToGit {

	@SuppressWarnings("static-access")
	public Object upload(String fileName) {
		String encodedString= null;
		String fileName1 = "C:\\Users\\bi301759\\Desktop\\xmlsout\\"+fileName;
		try {
			  File f = new File(fileName1);
			  if(f.exists()){
				  System.out.println("File existed");
				  encodedString =  new EncodeStringToBase64().encode(new ReadFile().readFile(fileName1));
			  }else{
				  System.out.println("File not found!");
			  }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return encodedString;
	}
	
	public Object uploadFromUi(StringBuffer filedata) {
		String encodedString= null;
		encodedString =  new EncodeStringToBase64().encode(filedata);
		return encodedString;
	}
	
}
