package com.wipro.gitapp.controller;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.wipro.gitapp.functions.DownloadFromGit;
import com.wipro.gitapp.functions.ReadFile;
import com.wipro.gitapp.utility.HttpClientGet;
import com.wipro.gitapp.utility.HttpClientPut;
import com.wipro.gitapp.utility.HttpClientPutForUi;

/**
 * A controller class for application.
 * @author bipin
 *
 */
@Controller
@RestController
public class GitController {
	
	// You have to modify the path here.
	public static final String DEFAULT_OUT_DIR = "C:\\Users\\bi301759\\Desktop\\xmlsout\\";
	private static final String DEFAULT_IN_DIR = "C:\\Users\\bi301759\\Desktop\\xmlsin\\";
	private static final String FILE_EXT = ".xml";

	@RequestMapping(value = "/download", method = RequestMethod.GET, produces="application/json")
	public @ResponseBody String downloadFilesfronGitRepo() {
		JSONArray getArray =null;
		JSONObject jobj = new JSONObject();
		String url = "https://api.github.com/repos/bipin-yadav/xmls/contents/";
		try {
			HttpClientGet httpClientGet = new HttpClientGet();
			String res = httpClientGet.mainController(url);		
			getArray = (JSONArray) new JSONParser().parse(res);		 
			//System.out.println(getArray);
			for(int i = 0; i < getArray.size(); i++){
			      JSONObject objects = (JSONObject) getArray.get(i);
			      System.out.println(objects);
			      String type = (String) objects.get("type");
			      if(type.equalsIgnoreCase("file")){
			    	  if(new DownloadFromGit().downloadFile((String) objects.get("download_url"), DEFAULT_IN_DIR)){
			    		  jobj.put(objects.get("name"), objects);
			    	  } else{ 
			    		  jobj.put(objects.get("name"), "Not downloaded.");
			    	  }
			      } else {
			    	  System.out.println("This is a diretory: Make api call agin to get the URL of files inside it.");
			    	  //make call here.
			    	  System.out.println(objects.get("url"));
			    	  String insideDirRes = httpClientGet.mainController((String) objects.get("url"));
			    	  JSONArray insideDirJsonArray = (JSONArray) new JSONParser().parse(insideDirRes);
			    	  System.out.println(insideDirJsonArray);
			    	  for(int j = 0; j < insideDirJsonArray.size(); j++){
						      JSONObject insideDirObjects = (JSONObject) insideDirJsonArray.get(j);
						      System.out.println("insideDirObject====="+insideDirObjects);
						      if(new DownloadFromGit().downloadFile((String) insideDirObjects.get("download_url"), DEFAULT_IN_DIR)){
						    	  jobj.put(insideDirObjects.get("name"), insideDirObjects);
						      } else{ 
					    		  jobj.put(insideDirObjects.get("name"), "Not downloaded.");
					    	  }
						 }
			      }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return jobj.toString();
	}
	
	@RequestMapping(value = "/upload/{fileName}", method = RequestMethod.GET, produces="application/json")
	public @ResponseBody String uploadFilesfronGitRepoReadNameFromPathVar(@PathVariable("fileName") String fileName) {
		JSONObject jobj = new JSONObject();
		String fileNameWithExtn = fileName+FILE_EXT;
		String url = "https://api.github.com/repos/bipin-yadav/xmls/contents/"+fileNameWithExtn;
		System.out.println(url);
		HttpClientPut httpClientput = new HttpClientPut();
		jobj.put(fileName, httpClientput.mainController(url,fileNameWithExtn));
		return jobj.toString();
	}
	
	@RequestMapping(value = "/upload", method = RequestMethod.GET, produces="application/json")
	public @ResponseBody String uploadFilesfronGitRepoReadFileNameFromDirectory() {
		JSONObject jobj = new JSONObject();
		HttpClientPut httpClientput = null;
		File[] files = new ReadFile().listFile(DEFAULT_OUT_DIR);
		for (int i = files.length-1; i >= 0; i--) {
			File file = files[i];
			System.out.println("File name: "+ file.getName());
			String url = "https://api.github.com/repos/bipin-yadav/xmls/contents/"+file.getName();
			httpClientput = new HttpClientPut();
			jobj.put(file.getName(), httpClientput.mainController(url,file.getName()));
		}
		return jobj.toString();
	}
	
	
	@RequestMapping(value="/videodata", method=RequestMethod.POST)
    public @ResponseBody String handleFileUpload(@RequestBody JSONObject jobj){
		JSONObject jobj2 = new JSONObject();
		String url = "https://api.github.com/repos/bipin-yadav/xmls/contents/"+jobj.get("fileName");
		System.out.println(url);
		HttpClientPut httpClientput = new HttpClientPut();
		jobj.put(jobj.get("fileName"), httpClientput.mainController(url,(String)jobj.get("data")));
		
        System.out.println("in handleFileUpload");
        //System.out.println(jobj.get("data"));
        return jobj.toString();
		
    }
	
	
	@RequestMapping(value="/uploadfromui", method=RequestMethod.POST)
    public @ResponseBody String handleFileUploadVideo(@RequestParam("file") MultipartFile file){
		String data = "";
		JSONObject jobj = new JSONObject();
		String fileName = file.getOriginalFilename();
		HttpClientPutForUi httpClientput = null;
		String url = "https://api.github.com/repos/bipin-yadav/xmls/contents/"+fileName;
        if (!file.isEmpty()) {
            try {
                byte[] bytes = loadFile((File) file);
                // intilize an InputStream
        		InputStream is = new ByteArrayInputStream(bytes);
        		StringBuffer result = getStringFromInputStream(is);
        		System.out.println("result-:"+result);
        		httpClientput = new HttpClientPutForUi();
    			jobj.put(file.getOriginalFilename(), httpClientput.mainController(url,result));
                System.out.println("You successfully uploaded " + file.getOriginalFilename());
                return jobj.toString();
            } catch (Exception e) {
            	System.out.println("You failed to upload " + fileName + " => " + e.getMessage());
                return "You failed to upload " + fileName + " => " + e.getMessage();
            }
        } else {
        	System.out.println("You failed to upload " + fileName + " because the file was empty.");
            return "You failed to upload " + fileName + " because the file was empty.";
        }
    }
	
	private byte[] loadFile(File file) throws IOException {
	    InputStream is = new FileInputStream(file);

	    long length = file.length();
	    if (length > Integer.MAX_VALUE) {
	        // File is too large
	    }
	    byte[] bytes = new byte[(int)length];
	    
	    int offset = 0;
	    int numRead = 0;
	    while (offset < bytes.length
	           && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	        offset += numRead;
	    }

	    if (offset < bytes.length) {
	        throw new IOException("Could not completely read file "+file.getName());
	    }

	    is.close();
	    return bytes;
	}
	
	// convert InputStream to String
		private static StringBuffer getStringFromInputStream(InputStream is) throws IOException {
			BufferedReader br = null;
			System.out.println(is.available());
			StringBuffer sb = new StringBuffer(is.available());
			String line;
			try {

				br = new BufferedReader(new InputStreamReader(is));
				while ((line = br.readLine()) != null) {
					sb.append(line);
					System.out.println(sb);
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return sb;
		}
	
}
 