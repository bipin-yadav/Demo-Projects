package com.wipro.gitapp.functions;

import javax.xml.bind.DatatypeConverter;

/**
 * EncodeStringToBase64 - encode the string into base64 encoding.
 * @author bipin
 *
 */
public class EncodeStringToBase64 {

	public static String  encode(StringBuffer str) {
		String encoded = null;
        // encode data using BASE64
		try{
			String readyString  = new String(str); 
			encoded = DatatypeConverter.printBase64Binary(readyString.getBytes());
			System.out.println("encoded value is \t" + encoded);
		} catch (Exception e){
			e.printStackTrace();
		}
        return encoded;
    }	
}
