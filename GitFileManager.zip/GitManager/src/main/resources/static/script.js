angular.module('myApp', ['naif.base64'])
.controller('ctrl', function($scope, $http, $window, $rootScope){

  $scope.onChange = function (e, fileList) {
    alert('this is on-change handler!');
  };
  
  $scope.download = function () {
	  var res = $http.get('/download');
		res.success(function(data, status, headers, config) {
			console.log(data);
			alert("All fils are downloaded");
		});
		res.error(function(data, status, headers, config) {
			console.log(data); 
		});
	  };
  
  $scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
    console.log('this is handler for file reader onload event!');
    console.log(file);
    //console.log(fileObj.base64);
    dataobj = {
			data : fileObj.base64,
			fileName : file.name
    }
    var res = $http.post('/videodata', angular.toJson(dataobj));
	res.success(function(data, status, headers, config) {
		console.log(data);
	});
	res.error(function(data, status, headers, config) {
		console.log(data); 
	});
    
  };

})