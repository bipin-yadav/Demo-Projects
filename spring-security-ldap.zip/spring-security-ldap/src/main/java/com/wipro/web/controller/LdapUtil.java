package com.wipro.web.controller;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class LdapUtil
{
	public static void main(String[] args)
	{
		String username = "bipin yadav";
		String password = "bipin";
		String base = "ou=users,dc=test,dc=com";
		String dn = "cn=" + username + "," + base;
		String ldapURL = "ldap://ec2-54-183-22-199.us-west-1.compute.amazonaws.com:389";

		// Setup environment for authenticating		
		Hashtable<String, String> environment = 
			new Hashtable<String, String>();
		environment.put(Context.INITIAL_CONTEXT_FACTORY,
				"com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(Context.PROVIDER_URL, ldapURL);
		environment.put(Context.SECURITY_AUTHENTICATION, "simple");
		environment.put(Context.SECURITY_PRINCIPAL, dn);
		environment.put(Context.SECURITY_CREDENTIALS, password);

		try
		{
			DirContext ctx = 
				new InitialDirContext(environment);
			
			// user is authenticated
			System.out.println(" Person Common Name: "+ctx);
			// Ask for all attributes of the object 
		    //Attributes attrs = ctx.getAttributes("cn=bipin yadav, ou=users");

		    // Find the surname attribute ("sn") and print it
		    //System.out.println("sn: " + attrs.get("sn").get());
		}
		catch (AuthenticationException ex)
		{
			
			ex.printStackTrace();

		}
		catch (NamingException ex)
		{
			ex.printStackTrace();
		}
	}
}
