CREATE TABLE `ccuser` (
  ID int(11) NOT NULL AUTO_INCREMENT,
  email varchar(100) NOT NULL,
  username varchar(100),
  password varchar(100),
  PRIMARY KEY (`ID`)
);

CREATE TABLE `ccissue` (
  ID int(11) NOT NULL AUTO_INCREMENT,
  title varchar(100) NOT NULL,
  issue varchar(100),
  author varchar(100),
  status varchar(50),
  PRIMARY KEY (`ID`)
);

insert into ccuser values(1,'bipinyadav@live.in','bipin','bipin');
