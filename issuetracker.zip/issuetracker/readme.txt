Sofware and tools required:
    Java 1.7 +,
    Maven,
    Mysql
    
Technologies Used:
Java, 
Spring, 
Angularjs, 
HTML, 
bootstrap, 
CSS
Mysql

Steps:
0. Install mysql create database name dbsearch and create table same as db.sql file.
{I have created Mysql instance at AWS server don't need to create db if you want.}
1. Install Java 1.7 and set PATH, CLASSPATH, JAVA_HOME environment variable.
2. Install maven and configure it set M2 and M2_HOME environment variable.
3. Build the Project Tracker by command: mvn clean package.
    3.1 Go to the Tacker project folder that have pom.xml file.
4. After that run command: java -jar target\Tracker-0.0.1-SNAPSHOT.jar
5. Open browser and type url: http://localhost:9090/.
