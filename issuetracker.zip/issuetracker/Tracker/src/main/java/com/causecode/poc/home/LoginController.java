package com.causecode.poc.home;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.causecode.poc.bean.UserLoginBean;
import com.causecode.poc.bean.UserSignupBean;
import com.causecode.poc.dao.LoginDao;

@RestController
public class LoginController {

   
    
    @RequestMapping(value="/logmein", method = RequestMethod.POST)
	public JSONObject aurthorLoginSubmit(@RequestBody UserLoginBean ab, Model model, HttpServletRequest req) {
        model.addAttribute("name", ab.getName());
        System.out.println("in loginme");
        JSONObject jobj = new JSONObject();
        String i = new LoginDao().validateUserLogin(ab);
		if(i.equalsIgnoreCase("success") ){
			jobj.put("status", "success");
	        jobj.put("message", "Login Successful.");
		} else {
			jobj.put("status", "fail");
		}
		return jobj;
    }
    
    @RequestMapping(value="/signup", method = RequestMethod.POST)
	public JSONObject aurthorSignupSubmit(@RequestBody UserSignupBean ab, Model model, HttpServletRequest req) {
        model.addAttribute("name", ab.getName());
        System.out.println("in signup");
        JSONObject jobj = new JSONObject();
        int i = new LoginDao().createUser(ab);
        if(i > 0 ){
			jobj.put("msg", "Signup successfully.");
			jobj.put("username", ab.getName());
		} else {
			jobj.put("msg", "please signup later");
		}
		return jobj;
    }
    
   
}
