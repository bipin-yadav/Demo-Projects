package com.causecode.poc.home;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.causecode.poc.bean.UserLoginBean;

@Controller
public class WebController {

    @RequestMapping("/")
    public String login(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        return "indexpage";
    }
    
    @RequestMapping("/welcome")
    public String home(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        System.out.println("in welcome get");
        return "homepage";
    }
    
    @RequestMapping(value="/welcome", method = RequestMethod.POST)
	public String aurthorLoginSubmit(@ModelAttribute UserLoginBean ab, Model model, HttpServletRequest req) {
        model.addAttribute("name", ab.getName());
        System.out.println("in welcome post");
        return "homepage";
    }
    
    @RequestMapping("/logout")
    public String logout(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        System.out.println("in home");
        return "homepage";
    }

}
