package com.causecode.poc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.causecode.poc.bean.UserLoginBean;
import com.causecode.poc.bean.UserSignupBean;


public class LoginDao {
	
	public String validateUserLogin(UserLoginBean ab) {
		Connection connection = null;
		String password = "";
		System.out.println("in validate "+ab.getName()+" "+ab.getPassword());
		if (ab.getName().isEmpty() || ab.getPassword().isEmpty()) {
			return "FAILED";
		} else {
			String sql = "select * from dbsearch.ccuser where username = ?";
			System.out.println(sql);
			try {
				connection = new NormalDbCOnnection().cretaeConnection();
				PreparedStatement ps = connection.prepareStatement(sql);
				ps.setString(1, ab.getName());
				ResultSet res = ps.executeQuery();
				while (res.next()) {
					password = res.getString("password");
					System.out.println(password);
				}
				if(password.equals(ab.getPassword())){
					System.out.println("sss");
					return "SUCCESS";
				} else {
					System.out.println("fff");
					return "FAILED";
				}

			} catch (SQLException sqle) {
				System.out.println(sqle);
				return "ERROR";
			} finally {
				if (connection != null) {
					try {
						connection.close();
					} catch (SQLException e) {
					}
				}
			}

		}

	}
	
	public int createUser(UserSignupBean ub) {
		String query = "insert into dbsearch.ccuser (username,email,password) values(?,?,?);";
		PreparedStatement pst;
		Connection connection = null;
		int i=0;
		try {	
			connection = new NormalDbCOnnection().cretaeConnection();
			System.out.println("********>>" + query + "<<*****");
			pst = connection.prepareStatement(query);
			pst.setString(1, ub.getName());
			pst.setString(2, ub.getEmail());
			pst.setString(3, ub.getPassword());
			try {
				i = pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}					
		return i;
	}	
	

}
