var routerApp = angular.module('routerApp', ['ui.router','ngAria', 'ngMessages', 'ngAnimate']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/login');
    $stateProvider
	    .state('login', {
	        url: '/login',
	        templateUrl: 'login.html',
	        controller:'SignUpController'
	    })
	    .state('welcome', {
            url: '/welcome',
            templateUrl: 'welcome.html'
        })
        .state('user', {
            url: '/user',
            templateUrl: 'manage-issue.html',
            controller: 'CustomersController'
        })
        .state('archive', {
            url: '/archive',
            templateUrl: 'partial-home.html',
            controller:'SignUpController'	
        })
        .state('archive.all', {
            url: '/all',
            templateUrl: 'table-data-all.html',
            controller:  'issueController'
        })
        .state('archive.open', {
            url: '/open',
            templateUrl: 'table-data-open.html',
            controller: 'issueController'
            	
        })
        .state('archive.closed', {
            url: '/closed',
            templateUrl: 'table-data-closed.html',
            controller: 'issueController'
            	
        })
        .state('create', {
            url: '/create',
            templateUrl: 'partial-create.html',
            controller: 'issueController'
        });
        
});

routerApp.controller('issueController', function($scope,customerService) {
    $scope.message = 'test';
    $scope.issues = customerService.getAllCustomers();
    
});

routerApp.service('customerService', function($http){
	console.log('inside customerService ');
	var customers = [];
	this.getAllCustomers = function(){
		customers = [];
		$http({
	        method : "GET",
	        url : "/getIssues"
	    }).then(function mySucces(response) {	         
	        console.log(response.data.users);
	        for (var i = 0; i < response.data.users.length; i++) {
	            //console.log(response.data.users[i]);
	            customers.push({
	                id: response.data.users[i].id,
	                title: response.data.users[i].title,
	                issue: response.data.users[i].issue,
	                author: response.data.users[i].author,
	                status: response.data.users[i].status
	            });
	        }
	    }, function myError(response) {
	    	console.log(response.data);
	    });
		
		return customers;
	};

  this.insertCustomer = function (title, issue, author) {
	  var topID = customers.length + 1;
	  var user = {
			  		id : topID,
				  	title: title,
				  	issue: issue,
		            author: author,
		            status: "Open"
	  			};
	  //console.log(JSON.stringify(user));
	  $http.post('/createIssue', user)
      .success(function (response) {
    	  //console.log(response.data);
    	  customers.push({
              id: topID,
              title: title,
              issue: issue,
              author: author,
              status: "Open"
          });
      })
      .error(function (response) {
    	  console.log(response.data);
      });	  
    };

    this.deleteCustomer = function (id) {
         console.log(id);
         for (var i = customers.length - 1; i >= 0; i--) {
             if (customers[i].id === id) {
                 customers.splice(i, 1);// to remove object
                 break;
             }
         }
    };
    
    this.editCustomer = function (id,title, lastName, city, email, author) {
        console.log("in service"+id);
        
   };

    this.getCustomer = function (id) {
        for (var i = 0; i < customers.length; i++) {
            if (customers[i].id === id) {
                return customers[i];
            }
        }
        return null;
    };
    
    this.updateStatusByid = function (id,title,issue,author,status) {
    	console.log("in updateStatusByid");
        for (var i = 0; i < customers.length; i++) {
            if (customers[i].id === id) {
            	customers[i].title = title;
            	customers[i].issue = issue;
            	customers[i].author = author;
            	customers[i].status = status;
            }
        }
        return null;
    };

});

routerApp.controller('CustomersController', function( $scope, $http,$location,$window, customerService ){
    console.log("inside CustomersController");
    $scope.newCustomer={};
    $scope.save=true;
    $scope.newCustomer.id = '';
    $scope.newCustomer.title = '';
    $scope.newCustomer.issue = '';
    $scope.newCustomer.author = '';
    $scope.newCustomer.status = '';
    
    $scope.customers = customerService.getAllCustomers();
    
    $scope.show =  function(){
    	console.log("in save");
    	return $scope.save;
    }
    
    $scope.insertCustomer = function () {
        var title = $scope.newCustomer.title;
        var issue = $scope.newCustomer.issue;
        var author = $scope.newCustomer.author;
        customerService.insertCustomer(title, issue, author);
        
        $scope.newCustomer.title = '';
        $scope.newCustomer.issue = '';
        $scope.newCustomer.author = '';
        
    };

    $scope.deleteCustomer = function (id) {
    	$http({
	        method : "GET",
	        url : "/delIssue?id="+id
	    }).then(function mySucces(response) {	         
	        console.log(response);	        
	    }, function myError(response) {
	    	console.log(response);
	    });
        customerService.deleteCustomer(id);       
    };
    
    $scope.editCustomer = function (id) {
        var customer = customerService.getCustomer(id);
        console.log(customer);
        $scope.save=false;
        $scope.newCustomer.id = id;
        $scope.newCustomer.title = customer.title;
        $scope.newCustomer.issue = customer.issue;
        $scope.newCustomer.author = customer.author;
        $scope.newCustomer.status = customer.status;
        //update(id,customer.title, customer.lastName, customer.city, customer.issue, customer.author);
        
    };
    
    $scope.updateCustomer = function () {
    	 console.log( $scope.newCustomer.title);
    	 console.log( $scope.newCustomer.id);
    	 console.log($scope.newCustomer.status);
    	 var user = {
    			 title : $scope.newCustomer.title,
    	 		 issue:$scope.newCustomer.issue,
    	 		 author:$scope.newCustomer.author,
    	 		 id: $scope.newCustomer.id,
    	 		 status: $scope.newCustomer.status
    	 }
    	 $http.post('/updateIssue', user)
         .success(function (response) {
       	  console.log(response.data);
         })
         .error(function (response) {
       	  console.log(response.data);
         });	
    	$location.path("/user");
    	 customerService.updateStatusByid(user.id,user.title,user.issue,user.author,user.status);
    	 //$window.location.reload();
    	 $scope.newCustomer.title = '';
         $scope.newCustomer.issue = '';
         $scope.newCustomer.author = '';
         $scope.newCustomer.status = '';
         $scope.save=true;
    }
    
});



routerApp.controller('SignUpController', function ($scope,$http,$location) {
    var ctrl = this,
    newCustomer = { email:'', userName:'', password:'' };    
    $scope.userName = '';
    $scope.password = '';
    $scope.message = 'Enter your credentials to login';
    
	var signup = function () {
	    if( ctrl.signupForm.$valid) {
	        ctrl.showSubmittedPrompt = true;
	        $scope.signupme();
	        clearForm();
	    }
	};
	
	$scope.signupme = function(){
		console.log("in signupme function" + $scope.userName);
		var user = {
			name : ctrl.newCustomer.userName,
			password : ctrl.newCustomer.password,
			email: ctrl.newCustomer.email
		}
		$http.post('/signup', user).success(function(response) {
			console.log(response);
			 if(response.status == "success"){
				 
				 $scope.userName = user.name;
				 $location.path("/");
			 }
		}).error(function(response) {
			console.log(response);
			$scope.message = response.message;
			 
		});	
		console.log("signup done");
	}
	
	$scope.loginme = function(){
		console.log("in login function" + $scope.userName);
		var user = {
			name : $scope.userName,
			password : $scope.password
		}
		$http.post('/logmein', user).success(function(response) {
			console.log(response);
			 if(response.status == "success"){
				 console.log("login success");
				 $scope.userName = user.name;
				$location.path("/welcome");
			 }
		}).error(function(response) {
			console.log(response);
			$scope.message = response.message;
			$location.path("/");
		});	
        
	}
	
	$scope.logmeout = function(){
		console.log("logmeout done"+$scope.userName);
		$http.get("/logout")
		  .then(function(response) {
		      $scope.myWelcome = response.data;
		      $scope.message = "Successfully Logout";
		      $location.path("/login");
		  });
	}
	
	var clearForm = function () {
	    ctrl.newCustomer = { email:'', userName:'', password:'' }
	    ctrl.signupForm.$setUntouched();
	    ctrl.signupForm.$setPristine();
	};
	
	var getPasswordType = function () {
	    return ctrl.signupForm.showPassword ? 'text' : 'password';
	};
	
	var toggleEmailPrompt = function (value) {
	    ctrl.showEmailPrompt = value;
	};
	
	var toggleUsernamePrompt = function (value) {
	    ctrl.showUsernamePrompt = value;
	};
	
	var hasErrorClass = function (field) {
	    return ctrl.signupForm[field].$touched && ctrl.signupForm[field].$invalid;
	};
	
	var showMessages = function (field) {
	    return ctrl.signupForm[field].$touched || ctrl.signupForm.$submitted
	};
	
	ctrl.showEmailPrompt = false;
	ctrl.showUsernamePrompt = false;
	ctrl.showSubmittedPrompt = false;
	ctrl.toggleEmailPrompt = toggleEmailPrompt;
	ctrl.toggleUsernamePrompt = toggleUsernamePrompt;
	ctrl.getPasswordType = getPasswordType;
	ctrl.hasErrorClass = hasErrorClass;
	ctrl.showMessages = showMessages;
	ctrl.newCustomer = newCustomer;
	ctrl.signup = signup;
	ctrl.clearForm = clearForm;
	});

routerApp.directive('validatePasswordCharacters', function () {
return {
    require: 'ngModel',
    link: function ($scope, element, attrs, ngModel) {
        ngModel.$validators.lowerCase = function (value) {
            var pattern = /[a-z]+/;
            return (typeof value !== 'undefined') && pattern.test(value);
        };
        ngModel.$validators.upperCase = function (value) {
            var pattern = /[A-Z]+/;
            return (typeof value !== 'undefined') && pattern.test(value);
        };
        ngModel.$validators.number = function (value) {
            var pattern = /\d+/;
            return (typeof value !== 'undefined') && pattern.test(value);
        };
        ngModel.$validators.specialCharacter = function (value) {
            var pattern = /\W+/;
            return (typeof value !== 'undefined') && pattern.test(value);
        };
        ngModel.$validators.eightCharacters = function (value) {
            return (typeof value !== 'undefined') && value.length >= 8;
        };
    }
}
});